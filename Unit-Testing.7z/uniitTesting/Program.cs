﻿using System;

namespace calculatorProgram
{
    public class Calculator
    {
        public static int Addition(int a, int b)
        {
            return a + b;
        }

        public static int Subtraction(int a, int b)
        {
            return a - b;
        }

        public static int Multiplication(int a, int b)
        {
            return a * b;
        }

        public static int Division(int a, int b)
        {
            if (b == 0)
                throw new DivideByZeroException("Деление на ноль невозможно");

            return a / b;
        }

        public static int Square(int a)
        {
            return a * a;
        }
    }

    class Program
    {
        static void Main()
        {
        strt:
            Console.Clear();
            Console.WriteLine("Введите первое число");
            int firstNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите второе число");
            int secondNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Выберите действие: \n1.Сложение\n2.Вычитание\n3.Умножение\n4.Деление\n5.Возведение в квадрат");
            int choose = Convert.ToInt32(Console.ReadLine());
            int result = 0;

            try
            {
                switch (choose)
                {
                    case 1:
                        result = Calculator.Addition(firstNumber, secondNumber);
                        Console.WriteLine($"{firstNumber} + {secondNumber} = {result}");
                        break;
                    case 2:
                        result = Calculator.Subtraction(firstNumber, secondNumber);
                        Console.WriteLine($"{firstNumber} - {secondNumber} = {result}");
                        break;
                    case 3:
                        result = Calculator.Multiplication(firstNumber, secondNumber);
                        Console.WriteLine($"{firstNumber} * {secondNumber} = {result}");
                        break;
                    case 4:
                        result = Calculator.Division(firstNumber, secondNumber);
                        Console.WriteLine($"{firstNumber} / {secondNumber} = {result}");
                        break;
                    case 5:
                        result = Calculator.Square(firstNumber);
                        Console.WriteLine($"{firstNumber}^2 = {result}");
                        break;
                    default:
                        Console.WriteLine("Неправильный выбор");
                        break;
                }
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine(e.Message);
            }

            Console.WriteLine("Нажмите любую кнопку, чтобы начать заново");
            Console.ReadKey();

            goto strt;
        }
    }
}
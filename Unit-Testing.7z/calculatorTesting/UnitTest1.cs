using calculatorProgram;

namespace calculatorTesting
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            [TestMethod]
            void AdditionTest()
            {
                int result = Calculator.Addition(5, 3);
                Assert.AreEqual(8, result);
            }

            [TestMethod]
            void SubtractionTest()
            {
                int result = Calculator.Subtraction(10, 4);
                Assert.AreEqual(6, result);
            }

            [TestMethod]
            void MultiplicationTest()
            {
                int result = Calculator.Multiplication(6, 7);
                Assert.AreEqual(42, result);
            }

            [TestMethod]
            void DivisionTest()
            {
                int result = Calculator.Division(20, 5);
                Assert.AreEqual(4, result);
            }

            [TestMethod]
            void DivisionByZeroTest()
            {
                Assert.ThrowsException<DivideByZeroException>(() => Calculator.Division(10, 0));
            }
        }
    }
}